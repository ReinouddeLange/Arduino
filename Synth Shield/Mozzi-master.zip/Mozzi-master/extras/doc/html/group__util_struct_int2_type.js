var group__util_struct_int2_type =
[
    [ "value", "group__util.html#a21bb06a1d9872a32b8729c961ae30eb0afc88b5b34784bb728b4172d2551fbfb4", null ]
];