var searchData=
[
  ['dcfilter',['DCfilter',['../class_d_cfilter.html',1,'']]]
];
