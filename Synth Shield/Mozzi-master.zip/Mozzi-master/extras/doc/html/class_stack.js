var class_stack =
[
    [ "Stack", "class_stack.html#ab034b819e2382f80d952cf8527dc6e6c", null ],
    [ "pop", "class_stack.html#afa9a35e13b68d9b59999227218a34d0a", null ],
    [ "push", "class_stack.html#af67739d9b82966da46f7496f4c1fc801", null ]
];